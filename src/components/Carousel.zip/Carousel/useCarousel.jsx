// useCarousel.js
import { useState, useEffect } from 'react';

export const useCarousel = (length, jumpDelay = 300) => {
  const [items, setItems] = useState([...Array(length * 2).keys()]);
  const [isTicking, setIsTicking] = useState(false);
  const [activeIdx, setActiveIdx] = useState(0);
  const bigLength = items.length;

  const sleep = (ms = 0) => new Promise((res) => setTimeout(res, ms));

  const prevClick = (jump = 1) => {
    if (!isTicking) {
      setIsTicking(true);
      setItems((prev) => prev.map((_, i) => prev[(i + jump) % bigLength]));
    }
  };

  const nextClick = (jump = 1) => {
    if (!isTicking) {
      setIsTicking(true);
      setItems((prev) => prev.map((_, i) => prev[(i - jump + bigLength) % bigLength]));
    }
  };

  const handleDotClick = (idx) => {
    if (idx < activeIdx) prevClick(activeIdx - idx);
    if (idx > activeIdx) nextClick(idx - activeIdx);
  };

  useEffect(() => {
    if (isTicking) sleep(jumpDelay).then(() => setIsTicking(false));
  }, [isTicking]);

  useEffect(() => {
    setActiveIdx((length - (items[0] % length)) % length);
  }, [items]);

  return {
    items,
    activeIdx,
    prevClick,
    nextClick,
    handleDotClick,
  };
};
