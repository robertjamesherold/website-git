export const slideWidth = 30;

export const items = [
    {
        player: {
            title: 'Efren Reyes',
            desc: 'Known as "The Magician", Efren Reyes is well regarded by many professionals...',
            image: 'https://i.postimg.cc/RhYnBf5m/er-slider.jpg',
        },
    },
    {
        player: {
            title: "Ronnie O'Sullivan",
            desc: 'Ronald Antonio O\'Sullivan is a six-time world champion...',
            image: 'https://i.postimg.cc/qBGQNc37/ro-slider.jpg',
        },
    },
    // usw.
];
