import React from 'react';
import { useSlideItem } from './useSlideItem';
import './useCarousel';

import { items as _item, slideWidth } from './carouselData';

export const CarouselSlideItem = ({ pos, idx, activeIdx, length }) => {
    const item = useSlideItem(pos, idx, _item, activeIdx, slideWidth, length);

    return (
        <li className="carousel__slide-item" style={item.styles}>
            <div className="carousel__slide-item-img-link">
                <img src={item.player.image} alt={item.player.title} />
            </div>
            <div className="carousel-slide-item__body">
                <h4>{item.player.title}</h4>
                <p>{item.player.desc}</p>
            </div>
        </li>
    );
};